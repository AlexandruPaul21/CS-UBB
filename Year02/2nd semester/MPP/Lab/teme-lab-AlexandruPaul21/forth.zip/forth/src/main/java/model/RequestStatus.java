package model;

public enum RequestStatus {
    Unknown, New, Finished, Cancelled;
}
